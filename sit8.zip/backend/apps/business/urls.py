from django.urls import path
from .views import (
    BusinessListCreateView,
    BusinessDetailView,
    BusinessUserListCreateView,
    BusinessUserDetailView,
)

urlpatterns = [
    path('', BusinessListCreateView.as_view(), name='business-list-create'),
    path('<uuid:pk>/', BusinessDetailView.as_view(), name='business-detail'),
    path('<uuid:business_pk>/users/', BusinessUserListCreateView.as_view(), name='business-user-list-create'),
    path('<uuid:business_pk>/users/<uuid:pk>/', BusinessUserDetailView.as_view(), name='business-user-detail'),
] 
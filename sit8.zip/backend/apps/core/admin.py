from django.contrib import admin
from .models import SystemSetting
from django.utils.translation import gettext_lazy as _

@admin.register(SystemSetting)
class SystemSettingAdmin(admin.ModelAdmin):
    """تنظیمات نمایش مدل SystemSetting در پنل ادمین"""
    list_display = ('key', 'value', 'description')
    search_fields = ('key', 'description')
    list_filter = ('key',)
    fieldsets = (
        (None, {
            'fields': ('key', 'value', 'description')
        }),
    )

    def get_readonly_fields(self, request, obj=None):
        """کلید فقط در حالت ویرایش، فقط خواندنی است"""
        if obj:  # در حالت ویرایش
            return ['key']
        return []

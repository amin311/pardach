from django.db import models
from django.utils.translation import gettext_lazy as _
import uuid
from PIL import Image
from io import BytesIO
from django.core.files.uploadedfile import InMemoryUploadedFile

class BaseModel(models.Model):
    """مدل پایه برای استفاده در همه مدل‌های دیگر"""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False, verbose_name=_("شناسه"))
    created_at = models.DateTimeField(auto_now_add=True, verbose_name=_("تاریخ ایجاد"))
    updated_at = models.DateTimeField(auto_now=True, verbose_name=_("آخرین بروزرسانی"))

    class Meta:
        abstract = True
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.__class__.__name__} ({self.id})"

class ThumbnailMixin(models.Model):
    """میکسین برای بهینه‌سازی خودکار تصاویر بندانگشتی"""
    thumbnail = models.ImageField(upload_to='thumbnails/', blank=True, null=True, verbose_name=_("تصویر بندانگشتی"))

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        if self.thumbnail:
            try:
                image = Image.open(self.thumbnail)
                if image.size[0] > 300:
                    image.thumbnail((300, 300))
                    output = BytesIO()
                    image.save(output, format='JPEG', quality=85)
                    output.seek(0)
                    self.thumbnail = InMemoryUploadedFile(
                        output, 'ImageField', f"{self.thumbnail.name.split('.')[0]}_thumb.jpg",
                        'image/jpeg', output.getbuffer().nbytes, None
                    )
            except Exception as e:
                from .utils import log_error
                log_error("Error optimizing thumbnail", e)
        super().save(*args, **kwargs)

class SystemSetting(models.Model):
    """مدل برای ذخیره و مدیریت تنظیمات سیستمی"""
    key = models.CharField(max_length=100, unique=True, verbose_name=_("کلید"))
    value = models.JSONField(verbose_name=_("مقدار"))
    description = models.TextField(blank=True, verbose_name=_("توضیحات"))

    def __str__(self):
        return self.key

    class Meta:
        verbose_name = _("تنظیمات سیستم")
        verbose_name_plural = _("تنظیمات سیستم")

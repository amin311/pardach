from rest_framework import serializers
from .models import SystemSetting

class SystemSettingSerializer(serializers.ModelSerializer):
    """سریالایزر برای تنظیمات سیستم"""
    class Meta:
        model = SystemSetting
        fields = ['key', 'value', 'description']
        read_only_fields = ['key']  # کلید فقط خواندنی در ویرایش 
from django.urls import path
from .views import SystemSettingView

urlpatterns = [
    path('settings/', SystemSettingView.as_view(), name='system_setting_list_create'),
    path('settings/<str:key>/', SystemSettingView.as_view(), name='system_setting_update'),
] 
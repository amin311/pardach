from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAdminUser
from rest_framework import status
from .models import SystemSetting
from .serializers import SystemSettingSerializer
from .utils import log_error

# Create your views here.

class SystemSettingView(APIView):
    """API برای مدیریت تنظیمات سیستمی"""
    permission_classes = [IsAdminUser]

    def get(self, request):
        """دریافت لیست تمام تنظیمات سیستمی"""
        try:
            settings = SystemSetting.objects.all()
            serializer = SystemSettingSerializer(settings, many=True)
            return Response(serializer.data)
        except Exception as e:
            log_error("Error retrieving system settings", e)
            return Response({'error': 'خطا در دریافت تنظیمات'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def post(self, request):
        """ایجاد یک تنظیم سیستمی جدید"""
        try:
            serializer = SystemSettingSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            log_error("Error creating system setting", e)
            return Response({'error': 'خطا در ایجاد تنظیم'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def put(self, request, key):
        """به‌روزرسانی یک تنظیم سیستمی بر اساس کلید آن"""
        try:
            setting = SystemSetting.objects.get(key=key)
            serializer = SystemSettingSerializer(setting, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except SystemSetting.DoesNotExist:
            return Response({'error': 'تنظیم یافت نشد'}, status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            log_error("Error updating system setting", e)
            return Response({'error': 'خطا در به‌روزرسانی تنظیم'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

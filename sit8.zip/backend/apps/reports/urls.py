from django.urls import path
from . import views

app_name = 'reports'

urlpatterns = [
    # مسیرهای URL اپلیکیشن reports
    # در صورت نیاز به مسیرهای واقعی، آنها را اینجا اضافه کنید
] 
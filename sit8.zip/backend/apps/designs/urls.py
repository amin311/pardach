from django.urls import path
from . import views

app_name = 'designs'

urlpatterns = [
    # مسیرهای URL اپلیکیشن designs
    # در صورت نیاز به مسیرهای واقعی، آنها را اینجا اضافه کنید
] 
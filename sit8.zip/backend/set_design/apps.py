from django.apps import AppConfig


class SetDesignConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'set_design'
